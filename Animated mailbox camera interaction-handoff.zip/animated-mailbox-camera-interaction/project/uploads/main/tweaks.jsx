/* Tweaks panel: edit letters, palette, etc. */

// Original authored pile transforms (matches the fallback in three-scene.js).
// Kept separate from the live/persisted letters data so "double-click to
// reset" always lands back on the intended layout, even after edits are saved.
const DEFAULT_PILE = [
  { x: -0.03, y: 0.037, z: -0.02, rotX: 0,    rotY: 11.5,  rotZ: 0 },
  { x: 0.06,  y: 0.073, z: 0.10,  rotX: 0,    rotY: -17.2, rotZ: 0 },
  { x: -0.07, y: 0.175, z: -0.40, rotX: 69.9, rotY: 5.7,   rotZ: 2.3 },
  { x: 0.07,  y: 0.190, z: -0.28, rotX: 60.2, rotY: -12.6, rotZ: -2.9 },
  { x: 0.00,  y: 0.150, z: 0.14,  rotX: 31.5, rotY: 4.6,   rotZ: 1.1 },
];
const DEFAULT_LIGHT_POS = { x: 0, y: 0.34, z: 0.08 };

function TweaksApp() {
  const [tweaks, setTweak] = useTweaks(window.LETTERS_DATA);
  const [editingIdx, setEditingIdx] = React.useState(null);
  const [previewingPile, setPreviewingPile] = React.useState(false);

  // Belt-and-suspenders persistence: save every tweak to localStorage (read
  // back by letters.jsx on load) since the host's on-disk save isn't wired
  // up in this project — without this, edits reset on the next reload.
  React.useEffect(() => {
    try { localStorage.setItem("loveLettersTweaks", JSON.stringify(tweaks)); } catch (e) {}
  }, [tweaks]);

  function updateLetter(i, patch) {
    const next = tweaks.letters.map((l, idx) => idx === i ? { ...l, ...patch } : l);
    setTweak("letters", next);
    syncLetters(next);
  }

  // Position/rotation of the decorative 3D envelope each letter maps to
  // (matched by array order). Patches persist via setTweak like any other
  // field, and also push straight into the live three.js scene so dragging a
  // slider moves the envelope in real time.
  function updatePile(i, patch) {
    const nextPile = { ...tweaks.letters[i].pile, ...patch };
    const next = tweaks.letters.map((l, idx) => idx === i ? { ...l, pile: nextPile } : l);
    setTweak("letters", next);
    syncLetters(next);
    if (window.ThreeScene && window.ThreeScene.setEnvelopePile) {
      window.ThreeScene.setEnvelopePile(i, nextPile);
    }
  }

  const lightPos = tweaks.lightPos || DEFAULT_LIGHT_POS;
  function updateLight(patch) {
    const next = { ...lightPos, ...patch };
    setTweak("lightPos", next);
    if (window.ThreeScene && window.ThreeScene.setLightPosition) {
      window.ThreeScene.setLightPosition(next);
    }
  }

  function togglePreviewPile() {
    const next = !previewingPile;
    setPreviewingPile(next);
    if (window.__previewPile) window.__previewPile(next);
  }

  // Push a letters-array change out to the live 2D view (App reads
  // window.LETTERS_DATA once at mount, so without this an edit/add/remove
  // here wouldn't show up until a full reload).
  function syncLetters(next) {
    window.LETTERS_DATA = { ...window.LETTERS_DATA, letters: next };
    window.dispatchEvent(new CustomEvent("letters-data-changed", { detail: window.LETTERS_DATA }));
  }

  function addLetter() {
    const next = [...tweaks.letters, {
      id: Date.now(),
      date: "Today",
      title: "A new one",
      envelopeColor: "#f4d6c0",
      wax: "#a5443a",
      body: "Write something here…"
    }];
    setTweak("letters", next);
    syncLetters(next);
  }

  function removeLetter(i) {
    const next = tweaks.letters.filter((_, idx) => idx !== i);
    setTweak("letters", next);
    syncLetters(next);
    if (editingIdx === i) setEditingIdx(null);
  }

  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Scene" />
      <TweakRadio
        label="Palette"
        value={tweaks.palette}
        onChange={v => setTweak("palette", v)}
        options={["sunset", "pastel", "dusk"]}
      />
      <TweakToggle
        label="Show flag"
        value={tweaks.showFlag}
        onChange={v => setTweak("showFlag", v)}
      />

      <TweakSection label="Mailbox envelope pile (3D)" />
      <TweakToggle
        label="Preview pile"
        value={previewingPile}
        onChange={togglePreviewPile}
      />
      <div style={{ fontSize: 11, opacity: 0.6, lineHeight: 1.4, marginTop: -4 }}>
        Opens the mailbox and drops the camera inside with no letters overlay, so you can
        see the 3D envelopes while nudging position/rotation below.
      </div>

      <label style={{ display: "block", fontSize: 11, marginTop: 10, marginBottom: 4, opacity: 0.7, textTransform: "uppercase", letterSpacing: 0.5 }}>
        Interior light position
      </label>
      <TweakSlider label="Left / right" value={lightPos.x} min={-0.4} max={0.4} step={0.005} defaultValue={DEFAULT_LIGHT_POS.x} onChange={v => updateLight({ x: v })} />
      <TweakSlider label="Up / down" value={lightPos.y} min={-0.1} max={0.7} step={0.005} defaultValue={DEFAULT_LIGHT_POS.y} onChange={v => updateLight({ y: v })} />
      <TweakSlider label="Front / back" value={lightPos.z} min={-0.5} max={0.5} step={0.005} defaultValue={DEFAULT_LIGHT_POS.z} onChange={v => updateLight({ z: v })} />

      <TweakSection label={`Letters (${tweaks.letters.length})`} />
      {tweaks.letters.map((l, i) => (
        <div key={l.id} style={{
          border: "1px solid rgba(0,0,0,0.1)",
          borderRadius: 8,
          padding: 10,
          marginBottom: 8,
          background: "rgba(255,243,230,0.5)"
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
            <div style={{ fontFamily: "Caveat, cursive", fontSize: 18, color: "#3a2820" }}>
              {l.title || "Untitled"}
            </div>
            <div style={{ display: "flex", gap: 4 }}>
              <button
                onClick={() => setEditingIdx(editingIdx === i ? null : i)}
                style={tinyBtn}>
                {editingIdx === i ? "−" : "edit"}
              </button>
              <button onClick={() => removeLetter(i)} style={{ ...tinyBtn, color: "#a44" }}>×</button>
            </div>
          </div>
          {editingIdx === i && (
            <div style={{ marginTop: 8 }}>
              <TweakText label="Title" value={l.title} onChange={v => updateLetter(i, { title: v })} />
              <TweakText label="Date" value={l.date} onChange={v => updateLetter(i, { date: v })} />
              <TweakColor label="Envelope" value={l.envelopeColor} onChange={v => updateLetter(i, { envelopeColor: v })} />
              <TweakColor label="Wax" value={l.wax} onChange={v => updateLetter(i, { wax: v })} />
              <label style={{ display: "block", fontSize: 11, marginTop: 8, marginBottom: 4, opacity: 0.7, textTransform: "uppercase", letterSpacing: 0.5 }}>
                Letter body
              </label>
              <textarea
                value={l.body}
                onChange={e => updateLetter(i, { body: e.target.value })}
                rows={8}
                style={{
                  width: "100%",
                  fontFamily: "Caveat, cursive",
                  fontSize: 16,
                  padding: 8,
                  border: "1px solid rgba(0,0,0,0.15)",
                  borderRadius: 6,
                  background: "#fdf6e9",
                  color: "#3a2820",
                  resize: "vertical",
                  boxSizing: "border-box"
                }}
              />
              {l.pile && (
                <div style={{ marginTop: 10, paddingTop: 8, borderTop: "1px solid rgba(0,0,0,0.08)" }}>
                  <label style={{ display: "block", fontSize: 11, marginBottom: 4, opacity: 0.7, textTransform: "uppercase", letterSpacing: 0.5 }}>
                    Position in mailbox pile
                  </label>
                  <TweakSlider label="Left / right" value={l.pile.x} min={-0.8} max={0.8} step={0.005} defaultValue={DEFAULT_PILE[i]?.x} onChange={v => updatePile(i, { x: v })} />
                  <TweakSlider label="Up / down" value={l.pile.y} min={-0.3} max={0.9} step={0.005} defaultValue={DEFAULT_PILE[i]?.y} onChange={v => updatePile(i, { y: v })} />
                  <TweakSlider label="Front / back" value={l.pile.z} min={-0.9} max={0.9} step={0.005} defaultValue={DEFAULT_PILE[i]?.z} onChange={v => updatePile(i, { z: v })} />
                  <TweakSlider label="Tilt up" value={l.pile.rotX} min={-90} max={180} step={1} unit="°" defaultValue={DEFAULT_PILE[i]?.rotX} onChange={v => updatePile(i, { rotX: v })} />
                  <TweakSlider label="Turn" value={l.pile.rotY} min={-90} max={90} step={1} unit="°" defaultValue={DEFAULT_PILE[i]?.rotY} onChange={v => updatePile(i, { rotY: v })} />
                  <TweakSlider label="Roll" value={l.pile.rotZ} min={-45} max={45} step={1} unit="°" defaultValue={DEFAULT_PILE[i]?.rotZ} onChange={v => updatePile(i, { rotZ: v })} />
                </div>
              )}
            </div>
          )}
        </div>
      ))}
      <TweakButton label="+ add letter" onClick={addLetter} />
    </TweaksPanel>
  );
}

const tinyBtn = {
  fontSize: 11,
  padding: "3px 8px",
  borderRadius: 4,
  border: "1px solid rgba(0,0,0,0.15)",
  background: "#fff",
  cursor: "pointer"
};

// mount tweaks into its own root
const tweakRoot = document.createElement("div");
document.body.appendChild(tweakRoot);
ReactDOM.createRoot(tweakRoot).render(<TweaksApp />);
