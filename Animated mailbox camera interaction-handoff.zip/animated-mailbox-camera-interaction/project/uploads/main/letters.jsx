/* Letter data — edit these to write real letters to her. */
const LETTERS_DATA = /*EDITMODE-BEGIN*/{
  "letters": [
    {
      "id": 1,
      "date": "Apr 14, 2026",
      "title": "Just because",
      "envelopeColor": "#f4d6c0",
      "wax": "#a5443a",
      "body": "My love,\n\nI was walking home today and the light hit the trees in that golden way you love, and I thought of you before I even noticed I was thinking. That's how it is now — you live somewhere underneath my thoughts, humming.\n\nI hope this little mailbox makes you smile. Open one whenever you need to feel close to me.\n\nForever yours,\nMe",
      "pile": { "x": -0.03, "y": 0.037, "z": -0.02, "rotX": 0, "rotY": 11.5, "rotZ": 0 }
    },
    {
      "id": 2,
      "date": "Apr 21, 2026",
      "title": "On a rainy day",
      "envelopeColor": "#e8d4b8",
      "wax": "#7a5a8a",
      "body": "Hi beautiful,\n\nIf it's raining where you are, I want you to know I'd happily run through it with you. I'd hold the worse umbrella so yours stayed dry. I'd hand you my jacket even if I froze a little.\n\nThere's no version of any weather I don't want to be in with you.\n\nYours,\nMe",
      "pile": { "x": 0.06, "y": 0.073, "z": 0.10, "rotX": 0, "rotY": -17.2, "rotZ": 0 }
    },
    {
      "id": 3,
      "date": "May 1, 2026",
      "title": "A small thing",
      "envelopeColor": "#f0c8b0",
      "wax": "#c87a4a",
      "body": "My darling,\n\nI noticed something this week — the way you laugh when you think no one's looking. It's softer. Slower. Like the laugh is just for you.\n\nI hope I get to hear that one for the rest of my life.\n\nAll of me,\nMe",
      "pile": { "x": -0.07, "y": 0.175, "z": -0.40, "rotX": 69.9, "rotY": 5.7, "rotZ": 2.3 }
    },
    {
      "id": 4,
      "date": "May 4, 2026",
      "title": "When you're far",
      "envelopeColor": "#dcc7a3",
      "wax": "#5a7a6a",
      "body": "Sweet thing,\n\nDistance is strange. It makes the small things bigger — your voice on the phone, a photo I've already seen ten times, the thought of you reading this.\n\nI'm counting the days. They're going faster than they feel.\n\nYours always,\nMe",
      "pile": { "x": 0.07, "y": 0.190, "z": -0.28, "rotX": 60.2, "rotY": -12.6, "rotZ": -2.9 }
    },
    {
      "id": 5,
      "date": "Whenever",
      "title": "An open one",
      "envelopeColor": "#f4ddc8",
      "wax": "#b85a4a",
      "body": "Love of my life,\n\nThis one doesn't have a date. Save it for a day you need it. A bad commute. A hard meeting. A 3pm when nothing feels right.\n\nWhen you open it, remember: I think you're the most extraordinary person I've ever met. And I get to love you. That's the luckiest thing in my life.\n\nUntil tonight,\nMe",
      "pile": { "x": 0.00, "y": 0.150, "z": 0.14, "rotX": 31.5, "rotY": 4.6, "rotZ": 1.1 }
    }
  ],
  "scene": "diorama",
  "palette": "sunset",
  "handwriting": "Caveat",
  "showFlag": true,
  "lightPos": { "x": 0, "y": 0.34, "z": 0.08 }
}/*EDITMODE-END*/;

window.LETTERS_DATA = LETTERS_DATA;

// Tweaks-panel edits (envelope pile position, light position, letter text,
// palette, etc.) persist to localStorage — the block above is just the
// original/default content. Without this, edits only lived in the page's
// in-memory React state and vanished on the next reload.
(function restoreTweaks() {
  try {
    const raw = localStorage.getItem("loveLettersTweaks");
    if (raw) Object.assign(window.LETTERS_DATA, JSON.parse(raw));
  } catch (e) { /* malformed/missing storage — fall back to defaults above */ }
})();
